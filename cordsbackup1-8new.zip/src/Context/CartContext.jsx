import { createContext, useContext, useState, useEffect, useMemo } from "react";

const CartContext = createContext(null);

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState(() => {
    const stored = localStorage.getItem("cart");
    return stored ? JSON.parse(stored) : [];
  });

  const [discount, setDiscount] = useState(0);
  const [promoCode, setPromoCode] = useState("");
  const [error, setError] = useState(null);

  // Save cart to localStorage
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cartItems));
  }, [cartItems]);

  // ---- Pricing Calculations ----
  const subtotal = useMemo(() => {
    return cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  }, [cartItems]);

  const gstAmount = useMemo(() => subtotal * 0.18, [subtotal]);
  const shipping = 0; // Free shipping
  const totalBeforeDiscount = subtotal + gstAmount + shipping;
  const finalTotal = Math.max(totalBeforeDiscount - discount, 0);

  // ---- Cart Functions ----
  const addToCart = (product) => {
    setCartItems((prevItems) => {
      const exists = prevItems.find((item) => item.id === product.id);
      const incomingQty = product.quantity || 1;

      if (exists) {
        return prevItems.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + incomingQty }
            : item
        );
      } else {
        return [...prevItems, { ...product, quantity: incomingQty }];
      }
    });
  };

  const removeFromCart = (id) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.id !== id));
  };

  const updateQuantity = (id, amount) => {
    setCartItems((prevItems) =>
      prevItems.map((item) =>
        item.id === id
          ? { ...item, quantity: Math.max(1, item.quantity + amount) }
          : item
      )
    );
  };

  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        removeFromCart,
        updateQuantity,
        cartCount,

        subtotal,
        gstAmount,
        shipping,
        totalBeforeDiscount,
        finalTotal,
        discount,
        setDiscount,
        promoCode,
        setPromoCode,
        error,
        setError,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
