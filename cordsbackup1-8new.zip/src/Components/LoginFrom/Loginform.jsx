import React, { useState, useContext } from "react";
import { toast } from "react-toastify";
import { loginCustomer } from "../../store/Services/AllApi";
import { useNavigate } from "react-router-dom";
import { UserContext } from "../../Context/UserContext";

const LoginForm = ({ onSwitchToRegister, onLoginSuccess }) => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(false);

    const navigate = useNavigate();
    const { setUser, pendingCheckout, setPendingCheckout } = useContext(UserContext);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        try {
            const data = await loginCustomer({ email, password });

            if (data.status) {
                const user = data.user;
                const token = user.token;

                if (!user || !token) {
                    toast.error("Missing user or token in the response.");
                } else {
                    localStorage.setItem("token", token);
                    localStorage.setItem("user", JSON.stringify(user));

                    setUser(user); // ✅ Update user in context
                    window.dispatchEvent(new Event("user-logged-in"));
                    toast.success("Login successful!");

                    // ✅ Post-login redirect
                    if (pendingCheckout?.type === "buyNow") {
                        navigate("/checkout", {
                            state: { buyNowProduct: pendingCheckout.product },
                        });
                    } else if (pendingCheckout?.type === "cart") {
                        navigate("/checkout");
                    }

                    setPendingCheckout(null); // ✅ Clear redirect intent
                    if (onLoginSuccess) onLoginSuccess(user); // ✅ Close modal
                }
            } else {
                toast.error(data.message || "Login failed. Please check your credentials.");
            }
        } catch (error) {
            console.error("Login error:", error);
            toast.error("Something went wrong. Please try again later.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="login-wrapper">
            <h2 className="login-title">Login</h2>

            <form className="login-form" onSubmit={handleSubmit}>
                <input
                    type="email"
                    placeholder="Email"
                    className="login-input"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />

                <input
                    type="password"
                    placeholder="Password"
                    className="login-input"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />

                <div className="login-options">
                    <label>
                        <input type="checkbox" /> Remember me
                    </label>
                    <a href="#" className="forgot-link">
                        Forgot Password?
                    </a>
                </div>

                <button type="submit" className="login-button" disabled={loading}>
                    {loading ? "Logging in..." : "Login"}
                </button>
            </form>

            <p className="register-text">
                Don’t have an account?{" "}
                <a href="#" onClick={onSwitchToRegister}>
                    Register
                </a>
            </p>
        </div>
    );
};

export default LoginForm;
