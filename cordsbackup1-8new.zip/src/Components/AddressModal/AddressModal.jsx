import React from "react";
import "./AddressModal.css";

const AddressModal = ({ onClose }) => {
    return (
        <div className="modal-overlay">
            <div className="modal-box">
                <div className="modal-header">
                    <h2>Add your address</h2>
                    <button className="close-button" onClick={onClose}>
                        &times;
                    </button>
                </div>
                <form className="address-form">
                    <div className="form-row">
                        <div className="form-group">
                            <label>First Name <span className="required">*</span></label>
                            <input type="text" placeholder="First Name" required />
                        </div>
                        <div className="form-group">
                            <label>Last Name <span className="required">*</span></label>
                            <input type="text" placeholder="Last Name" required />
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group">
                            <label>Phone <span className="required">*</span></label>
                            <input type="tel" placeholder="Phone" required />
                        </div>
                        <div className="form-group">
                            <label>Email <span className="required">*</span></label>
                            <input type="email" placeholder="Email" required />
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group">
                            <label>Company name</label>
                            <input type="text" placeholder="Company name" />
                        </div>
                        <div className="form-group">
                            <label>GST No.</label>
                            <input type="text" placeholder="GST No." />
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group">
                            <label>Street Address <span className="required">*</span></label>
                            <input type="text" placeholder="House number and street name" required />
                        </div>
                        <div className="form-group">
                            <label>Apartment, suite, unit, etc</label>
                            <input type="text" placeholder="Apartment" />
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group">
                            <label>Landmark</label>
                            <input type="text" placeholder="E.g. near apollo hospital" />
                        </div>
                        <div className="form-group">
                            <label>Town / City <span className="required">*</span></label>
                            <input type="text" placeholder="Town / City" required />
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group">
                            <label>PIN <span className="required">*</span></label>
                            <input type="text" placeholder="PIN" required />
                        </div>
                        <div className="form-group">
                            <label>State</label>
                            <select required>
                                <option value="">Select State</option>
                                <option value="Andaman & Nicobar Islands">Andaman & Nicobar Islands</option>
                                {/* More options here */}
                            </select>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group">
                            <label>Country</label>
                            <select required>
                                <option value="">Select Country</option>
                                <option value="India">India</option>
                            </select>
                        </div>
                        <div className="form-group save-btn-group">
                            <button type="submit" className="save-button">Save</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddressModal;
