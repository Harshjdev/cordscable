import React, { useState } from 'react';
import './AddressForm.css';

const AddressForm = () => {
    const [showShipping, setShowShipping] = useState(true);

    return (
        <form className="address-form">
            <h2>Billing Address</h2>
            <div className="form-grid">
                <div>
                    <label>First Name</label>
                    <input type="text" />
                </div>
                <div>
                    <label>Last Name </label>
                    <input type="text" />
                </div>
                <div>
                    <label>Phone</label>
                    <input type="tel" />
                </div>
                <div>
                    <label>Email</label>
                    <input type="email" defaultValue="ankit />
                </div>
                <div>
                    <label>Company name (optional)</label>
                    <input type="text />
                </div>
                <div>
                    <label>GST No.</label>
                    <input type="text" />
                </div>
                <div>
                    <label>Street Address *</label>
                    <input type="text" />
                </div>
                <div>
                    <label>Town / City *</label>
                    <input type="text" />
                </div>
                <div>
                    <label>State</label>
                    <select>
                        <option>Delhi</option>
                        <option>Maharashtra</option>
                    </select>
                </div>
                <div>
                    <label>PIN *</label>
                    <input type="text" />
                </div>
                <div>
                    <label>Country *</label>
                    <select >
                        <option>India</option>
                        <option>USA</option>
                    </select>
                </div>
            </div>

            <label className="checkbox">
                <input
                    type="checkbox"
                    checked={showShipping}
                    onChange={() => setShowShipping(!showShipping)}
                />
                Ship to a different address?
            </label>

            {showShipping && (
                <>
                    <h2>Shipping Address</h2>
                    <div className="form-grid">
                        <div>
                            <label>First Name *</label>
                            <input type="text" />
                        </div>
                        <div>
                            <label>Last Name *</label>
                            <input type="text" />
                        </div>
                        <div>
                            <label>Phone *</label>
                            <input type="tel" />
                        </div>
                        <div>
                            <label>Email *</label>
                            <input type="email" />
                        </div>
                        <div>
                            <label>Company name (optional)</label>
                            <input type="text" />
                        </div>
                        <div>
                            <label>GST No.</label>
                            <input type="text" />
                        </div>
                        <div>
                            <label>Street Address *</label>
                            <input type="text" />
                        </div>
                        <div>
                            <label>Town / City *</label>
                            <input type="text" />
                        </div>
                        <div>
                            <label>State</label>
                            <select >
                                <option>Andaman & Nicobar Islands</option>
                                <option>Delhi</option>
                            </select>
                        </div>
                        <div>
                            <label>PIN *</label>
                            <input type="text" />
                        </div>
                        <div>
                            <label>Country *</label>
                            <select >
                                <option>India</option>
                                <option>USA</option>
                            </select>
                        </div>
                    </div>
                </>
            )}

            <button type="submit" className="save-btn">Save address</button>
        </form>
    );
};

export default AddressForm;
