import "./Tags.css";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useState } from "react";
import { useMemo } from "react";

const Tags = ({ tagsData, limit, enableShowMore = false, onTagClick }) => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [showAll, setShowAll] = useState(false);

  const tags = useMemo(() => {
    const raw = Array.isArray(tagsData?.data)
      ? tagsData.data
      : Array.isArray(tagsData)
        ? tagsData
        : [];
    return [...raw].sort(() => Math.random() - 0.5); // clone and shuffle once
  }, [tagsData]);

  const visibleTags = enableShowMore
    ? showAll
      ? tags
      : tags.slice(0, limit || 2)
    : tags;

  const handleClick = (tagId) => {
    if (onTagClick) {
      onTagClick(tagId);
    } else {
      const newParams = new URLSearchParams(); // fresh, clean params
      newParams.set("tag", tagId);
      navigate(`/product?${newParams.toString()}`);
    }
  };
  ;


  return (
    <div className={`tags-container ${enableShowMore ? "expandable-tags" : ""}`}>
      <div className="tags-box">
        {visibleTags.map((item) => (
          <span
            key={item.id}
            className={`tag ${item.used_count > 39 ? "highlight-tag" : ""}`}
            onClick={() => handleClick(item.id)}
          >
            {item.title || item.name}
          </span>
        ))}
        {enableShowMore && !showAll && tags.length > (limit || 2) && (
          <button className="read-more-btn" onClick={() => setShowAll(true)}>
            +{tags.length - (limit || 2)} More
          </button>
        )}
      </div>
    </div>
  );
};

export default Tags;
