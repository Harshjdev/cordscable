import React, { useState } from 'react';
import './AddressForm.css';

const AddressForm = () => {
    const [showShipping, setShowShipping] = useState(true);

    return (
        <form className="address-form">
            <h2>Billing Address</h2>
            <div className="form-grid">
                <div>
                    <label>First Name *</label>
                    <input type="text" defaultValue="Ankit" />
                </div>
                <div>
                    <label>Last Name *</label>
                    <input type="text" defaultValue="Kumar" />
                </div>
                <div>
                    <label>Phone *</label>
                    <input type="tel" defaultValue="4544546546" />
                </div>
                <div>
                    <label>Email *</label>
                    <input type="email" defaultValue="ankitgtranketkeshlesi.com" />
                </div>
                <div>
                    <label>Company name (optional)</label>
                    <input type="text" defaultValue="hfgh" />
                </div>
                <div>
                    <label>GST No.</label>
                    <input type="text" defaultValue="hghjgh" />
                </div>
                <div>
                    <label>Street Address *</label>
                    <input type="text" defaultValue="H. No - 468, H - Block" />
                </div>
                <div>
                    <label>Town / City *</label>
                    <input type="text" defaultValue="old Delhi" />
                </div>
                <div>
                    <label>State</label>
                    <select defaultValue="Delhi">
                        <option>Delhi</option>
                        <option>Maharashtra</option>
                    </select>
                </div>
                <div>
                    <label>PIN *</label>
                    <input type="text" defaultValue="110047" />
                </div>
                <div>
                    <label>Country *</label>
                    <select defaultValue="India">
                        <option>India</option>
                        <option>USA</option>
                    </select>
                </div>
            </div>

            <label className="checkbox">
                <input
                    type="checkbox"
                    checked={showShipping}
                    onChange={() => setShowShipping(!showShipping)}
                />
                Ship to a different address?
            </label>

            {showShipping && (
                <>
                    <h2>Shipping Address</h2>
                    <div className="form-grid">
                        <div>
                            <label>First Name *</label>
                            <input type="text" defaultValue="Amit" />
                        </div>
                        <div>
                            <label>Last Name *</label>
                            <input type="text" defaultValue="Kumar" />
                        </div>
                        <div>
                            <label>Phone *</label>
                            <input type="tel" defaultValue="9988558421" />
                        </div>
                        <div>
                            <label>Email *</label>
                            <input type="email" defaultValue="tranik@gmail.com" />
                        </div>
                        <div>
                            <label>Company name (optional)</label>
                            <input type="text" defaultValue="trank" />
                        </div>
                        <div>
                            <label>GST No.</label>
                            <input type="text" defaultValue="gjtomj" />
                        </div>
                        <div>
                            <label>Street Address *</label>
                            <input type="text" defaultValue="H. No - 437, H - Block" />
                        </div>
                        <div>
                            <label>Town / City *</label>
                            <input type="text" defaultValue="New Delhi" />
                        </div>
                        <div>
                            <label>State</label>
                            <select defaultValue="Andaman & Nicobar Islands">
                                <option>Andaman & Nicobar Islands</option>
                                <option>Delhi</option>
                            </select>
                        </div>
                        <div>
                            <label>PIN *</label>
                            <input type="text" defaultValue="110047" />
                        </div>
                        <div>
                            <label>Country *</label>
                            <select defaultValue="India">
                                <option>India</option>
                                <option>USA</option>
                            </select>
                        </div>
                    </div>
                </>
            )}

            <button type="submit" className="save-btn">Save address</button>
        </form>
    );
};

export default AddressForm;
