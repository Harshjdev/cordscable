import { useNavigate } from "react-router-dom";
import "./Marquee.css";

const Marquee = ({ content, brandsData = [], clients = [], headline, speed = 5 }) => {
    const navigate = useNavigate();
    const headlineText = headline?.status ? headline.data : null;

    const hasLoopData =
        (brandsData?.data?.length || 0) > 0 ||
        clients.length > 0 ||
        (Array.isArray(content) ? content.length > 0 : !!content);

    const combinedImages = [
        ...(brandsData?.data || []).map((item, index) => ({
            src: item.image_url,
            alt: item.title || `brand-${index}`,
            brand_id: item.id,
        })),
        ...clients.map((img, index) => ({
            src: img.src,
            alt: img.alt || `client-${index}`,
        })),
    ];

    const handleBrandClick = (brandId) => {
        navigate(`/brand?brand_id=${brandId}`);
    };


    console.log("south", brandsData)
    return (
        <div className="marquee-wrapper">
            {/* Headline */}
            {headlineText && (
                <div className="headline-container">
                    <div
                        className="marquee-headline-scroll"
                    >
                        <span className="marquee-headline">{headlineText}</span>
                    </div>
                </div>
            )}

            {/* Brand/Client Marquee */}
            {hasLoopData && (
                <div className="marquee-loop-wrapper">
                    <div
                        className="marquee-loop"
                    >
                        {Array.isArray(content)
                            ? content.map((text, index) => (
                                <span key={`text-${index}`} className="marquee-text">
                                    {text}
                                </span>
                            ))
                            : content && (
                                <span className="marquee-text">{content}</span>
                            )}

                        {combinedImages.map((img, index) => (
                            <img
                                key={`loop-img-${index}`}
                                src={img.src}
                                alt={img.alt}
                                className="marquee-image"
                                onClick={() => img.brand_id && handleBrandClick(img.brand_id)}
                            />
                        ))}

                    </div>
                </div>
            )}
        </div>
    );
};

export default Marquee;
