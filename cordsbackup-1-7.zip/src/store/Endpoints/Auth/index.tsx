import { defaults } from "../default";

export const authEndpoints = {};
