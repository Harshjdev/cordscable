import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import Header from "../../Components/Header/Header";
import Footer from "../../Components/Footer/Footer";
import "./BrandComp.css"
import { getheadline } from "../../store/Services/AllApi";
import { mostUsedTags } from "../../store/Services/AllApi";
import { cordsCategory } from "../../store/Services/AllApi";
import Marquee from "../../Components/Marquee/Marquee";

const BrandComp = () => {
    const [searchParams] = useSearchParams();
    const [headline, setHeadline] = useState([]);
    const brandId = searchParams.get("brand_id");

    const [brand, setBrand] = useState({});
    const [tagsData, setTagsData] = useState([]);
    const [categoryData, setCategoryData] = useState([]);
    useEffect(() => {
        cordsCategory({ body: {} })
            .then((response) => {
                setCategoryData(response)
            })
            .catch((error) => {
                console.error("Error fetching cruise categories:", error);
            });
        getheadline({ body: {} })
            .then((headlineres) => {
                console.log("headline", headlineres)
                setHeadline(headlineres);
            })
            .catch((error) => {
                console.error("Error fetching cruise categories:", error);
            })
        mostUsedTags({ body: {} }).then((res) => {
            setTagsData(res)
        }).catch((error) => {
            console.log("error occured in tags", error)
        })
    }, []);

    useEffect(() => {
        if (brandId) {
            const fetchBrandData = async () => {
                try {
                    const response = await fetch(`https://cords.tranktechnologies.com/api/about-brand?brand_id=${brandId}`);
                    const result = await response.json();
                    if (result.status && result.data) {
                        setBrand(result.data);
                    } else {
                        console.error("Invalid brand data");
                    }
                } catch (error) {
                    console.error("Failed to fetch brand data:", error);
                }
            };

            fetchBrandData();
        }
    }, [brandId]);

    return (
        <div className="brandpage">
            <Header tagsData={tagsData} categoryData={categoryData} />
            <Marquee headline={headline} />
            <div className="brand-page" style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto" }}>


                {brand.image_url && (
                    <img
                        src={brand.image_url}
                        alt={`Brand ${brandId}`}
                        style={{ maxWidth: "100%", height: "auto", marginBottom: "2rem" }}
                    />
                )}

                <div
                    className="brand-content"
                    dangerouslySetInnerHTML={{ __html: brand.content }}
                />
            </div>
            <Footer />
        </div>

    );
};

export default BrandComp;
