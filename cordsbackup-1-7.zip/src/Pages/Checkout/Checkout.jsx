import "./Checkout.css";
import logo from '../../assets/StockYard-logo.svg';
import { useCart } from "../../Context/CartContext";
import { useState, useMemo } from "react";
import AddressModal from "../../Components/AddressModal/AddressModal";
import { useNavigate, useLocation } from "react-router-dom";

const Checkout = () => {
    const { cartItems, subtotal, gstAmount, shipping, discount, finalTotal } = useCart();
    const navigate = useNavigate();
    const location = useLocation();
    const [showModal, setShowModal] = useState(false);
    const [expandedTitles, setExpandedTitles] = useState({});

    const buyNowProduct = location.state?.buyNowProduct || null;
    const isBuyNow = !!buyNowProduct;

    const toggleTitle = (index) => {
        setExpandedTitles((prev) => ({
            ...prev,
            [index]: !prev[index],
        }));
    };

    // Either cartItems or buyNowProduct (only one shown)
    const productsToRender = isBuyNow ? [buyNowProduct] : cartItems;

    // If "Buy Now", calculate everything separately
    const buyNowSubtotal = useMemo(() => {
        return buyNowProduct ? buyNowProduct.final_price * buyNowProduct.quantity : 0;
    }, [buyNowProduct]);

    const buyNowGst = useMemo(() => buyNowSubtotal * 0.18, [buyNowSubtotal]);

    const buyNowTotal = useMemo(() => buyNowSubtotal + buyNowGst, [buyNowSubtotal, buyNowGst]);

    const buyNowDiscountedTotal = useMemo(() => buyNowTotal - discount, [buyNowTotal, discount]);

    const getShortTitle = (title) => {
        const words = title.split(" ");
        return words.length <= 9 ? title : words.slice(0, 9).join(" ") + "...";
    };

    const handleLogoClick = () => {
        navigate('/');
    };

    return (
        <div className="checkout-wrapper">
            {showModal && <AddressModal onClose={() => setShowModal(false)} />}
            <header className="checkout-header">
                <div className="logo" onClick={handleLogoClick}>
                    <img src={logo} alt="Stockyard Logo" />
                </div>
            </header>

            <div className="checkout-container">
                <div className="checkout-left">
                    {/* Progress Steps */}
                    <div className="step-progress">
                        <div className="step-labels">
                            <span className="step-text active">Address</span>
                            <span className="step-text">Payment</span>
                        </div>
                        <div className="progress-line">
                            <div className="line-fill"></div>
                            <div className="step-circle"></div>
                        </div>
                    </div>

                    {/* Saved Address */}
                    <div className="card-box">
                        <div className="card-title">Saved Address</div>
                        <div className="address-list">
                            <div className="address-item">
                                <span>H.No – 465, H – Block somnarg Jammu & Kashmir 110047</span>
                                <span className="edit-icon">✎</span>
                            </div>
                            <div className="address-item">
                                <span>H.No – 465, H – Block old Delhi Andaman & Nicobar Islands 110049</span>
                                <span className="edit-icon">✎</span>
                            </div>
                            <div className="add-address" onClick={() => setShowModal(true)}>+ Add Address</div>
                        </div>
                    </div>

                    {/* Order Summary */}
                    <div className="card-box">
                        <div className="card-title">Order Summary</div>
                        {productsToRender.length > 0 ? (
                            <div className="checkout-products">
                                {productsToRender.map((item, index) => {
                                    const fullTitle = item.title;
                                    const shortTitle = getShortTitle(item.title);
                                    const isExpanded = expandedTitles[index];

                                    return (
                                        <div className="checkout-product-item" key={index}>
                                            <img
                                                src={item.feature_image_url}
                                                alt={item.title}
                                                className="checkout-product-img"
                                            />
                                            <div className="checkout-product-details">
                                                <div className="checkout-product-title">
                                                    {isExpanded ? fullTitle : shortTitle}
                                                    {fullTitle.split(" ").length > 9 && (
                                                        <span
                                                            className="read-more"
                                                            onClick={() => toggleTitle(index)}
                                                        >
                                                            {isExpanded ? " Show less" : " Read more"}
                                                        </span>
                                                    )}
                                                </div>

                                                {item.selectedVariantInfo && (
                                                    <div className="checkout-item-variants">
                                                        {Object.entries(item.selectedVariantInfo).map(([name, value]) => (
                                                            <p key={name} className="variant-detail">
                                                                <strong>{name}:</strong> {value}
                                                            </p>
                                                        ))}
                                                    </div>
                                                )}

                                                <div className="checkout-price-info">
                                                    <span className="original-price">₹{item.price}</span>
                                                    <span className="final-price">₹{item.final_price}</span>
                                                    <span className="checkout-discount">{item.discount}% Off</span>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        ) : (
                            <p>No items in cart.</p>
                        )}
                    </div>

                    {/* Payment Method */}
                    <div className="card-box">
                        <div className="card-title">Payment Details</div>
                        <div className="payment-options">
                            <label><input type="radio" name="payment" /> UPI</label>
                            <label><input type="radio" name="payment" /> Wallets</label>
                            <label><input type="radio" name="payment" /> Debit / Credit Card</label>
                            <label><input type="radio" name="payment" /> Net Banking</label>
                            <label><input type="radio" name="payment" /> Cash on Delivery</label>
                        </div>
                    </div>
                </div>

                {/* Payment Summary Right */}
                <div className="checkout-right">
                    <div className="payment-summary">
                        <h3>Payment Summary</h3>
                        <p className="products-note">
                            Your shopping cart contains {productsToRender.length} {productsToRender.length === 1 ? "product" : "products"}
                        </p>

                        {/* Summary Rows */}
                        <div className="summary-row">
                            <span>Subtotal Amount</span>
                            <span>₹ {isBuyNow ? buyNowSubtotal.toFixed(2) : subtotal.toFixed(2)}</span>
                        </div>
                        <div className="summary-row">
                            <span>GST</span>
                            <span>₹ {isBuyNow ? buyNowGst.toFixed(2) : gstAmount.toFixed(2)}</span>
                        </div>
                        <div className="summary-row">
                            <span>Shipping Payment</span>
                            <span>Free</span>
                        </div>
                        <div className="summary-row total">
                            <span>Total Payment</span>
                            <span>₹ {isBuyNow ? buyNowDiscountedTotal.toFixed(2) : finalTotal.toFixed(2)}</span>
                        </div>
                        {discount > 0 && (
                            <p className="discount-applied">Discount applied: ₹{discount.toFixed(2)}</p>
                        )}

                        <button className="place-order-btn">Place Order</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Checkout;
